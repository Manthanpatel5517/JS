export{}
let y=2024;
console.log((y%4===0&&y%100!==0)||y%400===0);