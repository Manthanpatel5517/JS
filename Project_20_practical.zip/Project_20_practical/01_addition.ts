export{}
let a: number = 10;
let b: number = 20;
console.log("Sum =", a + b);