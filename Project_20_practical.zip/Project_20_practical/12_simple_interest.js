let p = 1000, r = 5, t = 2;
console.log((p * r * t) / 100);
export {};
