"use strict";
let x = 5, y = 10;
[x, y] = [y, x];
console.log(x, y);
